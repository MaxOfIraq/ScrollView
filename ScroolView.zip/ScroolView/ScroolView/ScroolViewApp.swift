//
//  ScroolViewApp.swift
//  ScroolView
//
//  Created by Ahmed Salah on 22/08/2022.
//

import SwiftUI

@main
struct ScroolViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
