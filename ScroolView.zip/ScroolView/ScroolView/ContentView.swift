//
//  ContentView.swift
//  ScroolView
//
//  Created by Ahmed Salah on 22/08/2022.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ScrollView(.vertical, showsIndicators: false){
            Rectangle()
                .frame(width: 300, height: 200)
                .padding()
            
            
            Rectangle()
                .frame(width: 300, height: 200)
                .padding()
            
            
            Rectangle()
                .frame(width: 300, height: 200)
                .padding()
            
            
            
            Rectangle()
                .frame(width: 300, height: 200)
                .padding()
            
            
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
